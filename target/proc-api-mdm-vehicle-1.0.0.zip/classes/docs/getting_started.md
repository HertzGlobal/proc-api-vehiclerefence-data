This is a sample Getting Started page
-------------------------------------------

## Requirements:
- JDK 1.8
- Maven 3


Tests in the examples will open ports while they run, like 8080, so watch out for potential conflicts. 

## Install
To build and run tests run:

    mvn clean install


## Runtime
To access the API...

## Conclusion